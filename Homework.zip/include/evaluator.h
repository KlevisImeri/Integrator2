#ifndef evaluator_h
#define evaluator_h
class Evaluator{
 private:
    
 public:
    Evaluator(/* args */);
    ~Evaluator();
};


#endif