#include "evaluator.h"

Evaluator::Evaluator(/* args */)
{
}

Evaluator::~Evaluator()
{
}